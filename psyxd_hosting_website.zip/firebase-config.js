const firebaseConfig = {
  apiKey: "AIzaSyBpXFoOnbbVntQ7UEMSf08G_RCrBkLR1Fs",
  authDomain: "psyxdhosting.firebaseapp.com",
  projectId: "psyxdhosting",
  storageBucket: "psyxdhosting.firebasestorage.app",
  messagingSenderId: "902116217148",
  appId: "1:902116217148:web:ecb6e72830056019fe4e39"
};

firebase.initializeApp(firebaseConfig);
window.auth = firebase.auth();